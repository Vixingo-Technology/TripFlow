import React from "react";
import Quote from "../components/sections/Quote";

export default function Insurance() {
    return (
        <>
            <Quote />
        </>
    );
}
